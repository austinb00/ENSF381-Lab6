import logo from './logo.svg';
import './App.css';

function App() {
  let date = new Date(); 
  let currentYear = date.getFullYear(); 
  
  return (
    <div className="App">
      <h1>ENSF 381: Full Stack Web Development</h1>
      <p>React Components</p>
      <p>{currentYear}</p>
      <Greet/>
    </div>
  );
}

function Greet(){
  let isLoggedIn = true; 

  if(isLoggedIn == true) {
    return (<div><p>Welcome back!</p></div>);
  }
  else {
    return (<div><p>Please log in.</p></div>);
  }
}


export default App;


function Contact(prop) {

    return (
    <div>
        <h2>{prop.title}</h2>
        <p>Contact Us</p>
        <p>{prop.description}</p>
    </div>
    ); 
}

export default Contact
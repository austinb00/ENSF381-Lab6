import './App.css';
import Home from './Home.js';
import Contact from './Contact.js';
import About from './About.js';

function App() {
  let date = new Date(); 
  let currentYear = date.getFullYear(); 
  
  return (
    <div className="App">
      <h1>ENSF 381: Full Stack Web Development</h1>
      <p>React Components</p>
      <p>{currentYear}</p>
      <Greet/>

      <Home title="Home Page" description="Welcome to our website."/>
      <About title="About Us" description="We are passionate about delivering quality experiences."/>
      <Contact title="Contact Us" description="Feel free to reach out to us via email or phone."/>
    </div>
  );
}

function Greet(){
  let isLoggedIn = true; 

  if(isLoggedIn == true) {
    return (<div><p>Welcome back!</p></div>);
  }
  else {
    return (<div><p>Please log in.</p></div>);
  }
}


export default App;


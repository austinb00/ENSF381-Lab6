function Home(prop) {

    return (
    <div>
        <h2>{prop.title}</h2>
        <p>Welcome to the Home Page</p>
        <p>{prop.description}</p>
    </div>
    ); 
};

export default Home
function About(prop) {

    return (
    <div>
        <h2>{prop.title}</h2>
        <p>About Us</p>
        <p>{prop.description}</p>
      
    </div>
    ); 
}

export default About
import logo from './logo.svg';
import './App.css';
import EngineeringTopics from './EngineeringTopics.js'

function App() {
  let date = new Date(); 
  let currentYear = date.getFullYear(); 
  
  return (
    <div className="App">
      
      <EngineeringTopics/>
    </div>
  );
}

export default App;

